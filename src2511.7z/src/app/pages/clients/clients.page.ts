import { Component, OnInit } from '@angular/core';


@Component({
  selector: 'app-clients',
  templateUrl: './clients.page.html',
  styleUrls: ['./clients.page.scss'],
})
export class ClientsPage implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
