import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-split-layout',
  templateUrl: './split-layout.page.html',
  styleUrls: ['./split-layout.page.scss'],
})
export class SplitLayoutPage implements OnInit {
  public appPages = [
    { title: 'Article', url: '/app/articles', icon: 'mail', child:[{title: 'Sub Article 1', url: '/app/articles', icon: 'mail'},{title: 'Sub Article 2', url: '/app/articles', icon: 'mail'}] },
    { title: 'Client', url: '/app/clients', icon: 'paper-plane' },
    { title: 'Favorites', url: '/folder/Favorites', icon: 'heart' },
    { title: 'Archived', url: '/folder/Archived', icon: 'archive' },
    { title: 'Trash', url: '/folder/Trash', icon: 'trash' },
    { title: 'Spam', url: '/folder/Spam', icon: 'warning' },
  ];
  constructor() { }

  ngOnInit() {
  }


  loadMenu (){
    
  }
}
