import { CommonModule } from '@angular/common';
import { NgModule } from "@angular/core";
import { RouterModule } from '@angular/router';
import { IonicModule, IonRouterOutlet } from '@ionic/angular';
import { HeaderComponent } from "./header/header.component";


@NgModule({
    declarations:[HeaderComponent],
    imports:[
        CommonModule                
    ],
    exports:[HeaderComponent]
})

export class ComponentsModule {}